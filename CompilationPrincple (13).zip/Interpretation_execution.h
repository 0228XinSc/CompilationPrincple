//
// Created by 86156 on 2021-11-18.
//

#ifndef COMPILATIONPRINCPLE_INTERPRETATION_EXECUTION_H
#define COMPILATIONPRINCPLE_INTERPRETATION_EXECUTION_H
#include "Table.h"
#include <vector>
#include <string>
#include <queue>
using namespace std;
/*数据栈*/
struct DataTable{
    DataTable(
            int _NameIndex,
            int _FuncIndex,
            int _Value
    ) :
        NameIndex(_NameIndex),
        FuncIndex(_FuncIndex),
        Value(_Value){}
    int NameIndex;//传TokenList 的i位
    int FuncIndex;//函数在PcodeList的下标,是函数时才赋值
    int Value;//变量值
};
extern vector<DataTable> DataStack;
extern vector<int> DataStackIndexTable;


/*运行栈实现*/
extern int RunStack[10000];
extern int RunStackTop;
/*数据存储表*/
extern int IntDataTable[100000];
extern int IntDataTableTop;
extern int ArrayStorageArea[100000];
extern int ArrayStorageAreaTop;
/* */
extern int IsFunc;
extern vector<int> RunStack_Func;
extern queue<int> PrintStack;
extern int indata;
//extern int MainReturn;

void Interpretation_execution();
void PCodeListPrint();
#endif //COMPILATIONPRINCPLE_INTERPRETATION_EXECUTION_H
